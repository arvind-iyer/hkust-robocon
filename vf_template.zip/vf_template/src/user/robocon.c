#include "robocon.h"


int y() {
	/*** XXX ***/

}


