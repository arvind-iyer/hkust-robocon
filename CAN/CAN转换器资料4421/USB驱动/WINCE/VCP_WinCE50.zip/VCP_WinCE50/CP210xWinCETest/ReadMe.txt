////////////////////////////////////////////////////////////////////////

FEATURE NAME:

CP210x Serial Test

MANUFACTURER:

Silicon Laboratories

CONTACT INFO:



DATE:



VERSION:



SIZE:



DESCRIPTION:



NOTES:



////////////////////////////////////////////////////////////////////////


========================================================================
       CONSOLE APPLICATION : CP210xSerialTest
========================================================================


AppWizard has created this CP210xSerialTest application for you.  

This file contains a summary of what you will find in each of the files that
make up your CP210xSerialTest application.

CP210xSerialTest.pbp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.pbp) file, but they should export the makefiles locally.

CP210xSerialTest.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named CP210xSerialTest.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
